<template>
    <div>
        <p>NotFound</p>
    </div>
</template>

<script>
export default {
    data(){
        return {}
    },
    components: {},
    methods: {},
    computed: {},
    watch: {},
    mounted(){}
}
</script>